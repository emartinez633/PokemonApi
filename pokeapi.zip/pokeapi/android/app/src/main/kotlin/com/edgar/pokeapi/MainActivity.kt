package com.edgar.pokeapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
