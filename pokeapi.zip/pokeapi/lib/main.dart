import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:pokeapi/models/models.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Material App',
      debugShowCheckedModeBanner: false,
      home: inicio(),
    );
  }
}

class inicio extends StatefulWidget {
  const inicio({super.key});

  @override
  State<inicio> createState() => _inicioState();
}

class _inicioState extends State<inicio> {
  Pokemons? pokemon;
  int pokemonId = 0;
  String? get pokename => pokemon?.name;

  @override
  void initState() {
    super.initState();
    GetPokemon();
  }

  Future<void> GetPokemon() async {
    pokemonId++;
    final response = await Dio().get(
      'https://pokeapi.co/api/v2/pokemon/$pokemonId/',
    );
    pokemon = Pokemons.fromJson(response.data);
    setState(() {});
  }

  Future<void> PreviousPokemon() async {
    if (pokemonId > 1) {
      pokemonId--;
    }

    final response = await Dio().get(
      'https://pokeapi.co/api/v2/pokemon/$pokemonId/',
    );
    pokemon = Pokemons.fromJson(response.data);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('App Pokémon $pokename \n ID: $pokemonId')),
      body: Center(
        child: Column(
          children: [
            Text(pokemon?.name ?? 'Cargando...', style: const TextStyle(fontSize: 30, fontFamily: 'Comic Sans MS')),
            Text(pokemon?.types.map((type) => type.type.name).join(', ') ?? ''),
            if (pokemon != null) 
            Image.network(pokemon!.sprites.frontDefault),
            Image.network(pokemon!.sprites.backDefault),
            Image.network(pokemon!.sprites.frontShiny),
            Image.network(pokemon!.sprites.backShiny),
          ],
        ),
      ),
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.center,

        children: [
          FloatingActionButton(
            heroTag: "prev_pokemon", // Se necesita un heroTag único
            onPressed: PreviousPokemon,
            child: const Icon(Icons.navigate_before_outlined),
          ),
          const SizedBox(width: 10),

          FloatingActionButton(
            heroTag: "next_pokemon", // Se necesita un heroTag único
            onPressed: GetPokemon,  
            child: const Icon(Icons.navigate_next_outlined),
          ),
        ],
      ),
    );
  }
}
